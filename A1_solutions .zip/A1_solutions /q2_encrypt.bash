#!/bin/bash 

codebook.txt=$1
test_input1.txt=$2

#create two variables holding the lines of the codebook

read -r lowercase1 < codebook.txt 
head -2 codebook.txt | tail -1 > codebook2.txt 
read -r uppercase1 < codebook2.txt 

#initalise the alphabets to be translated 

lowercase="abcdefghijklmnopqrstuvwxyz"
uppercase="ABCDEFGHIJKLMNOPQRSTUVWXYZ"

#create a variable holding the value of the message we want to encrpyt 

x=$(cat "test_input1.txt")

#use tr to encrpyt the message 

echo $x | tr $lowercase $lowercase1 | tr $uppercase $uppercase1 