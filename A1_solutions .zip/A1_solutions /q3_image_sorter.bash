#!/bin/bash

directorysearch=$1 

#variable with the name of the output picture, which works with '_' and '/'

picture="$(echo $directorysearch | tr '/' '_' )"

#we make a list with the path to the pictures, and put it in a single variable 

photos="$(find $directorysearch -exec stat -f '%m%t%Sm %N' {} + | sort -n |cut -f2 | grep .jpg | cut -f5 -d" " | xargs)"

convert $photos -append $picture.jpg



