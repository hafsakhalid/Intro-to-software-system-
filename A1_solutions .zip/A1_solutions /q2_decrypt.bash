#!/bin/bash 

codebook.txt=$1 
test_input1_encrypted.txt=$2 

#create variables to hold the lines of the codebook 

read -r lowercase1 < codebook.txt 
head -2 codebook.txt | tail -1 > codebook2.txt 
read -r uppercase1 < codebook2.txt 

#create variables for the alphabets 

lowercase='abcdefghijklmnopqrstuvwxyz'
uppercase='ABCDEFGHIJKLMNOPQRSTUVWXYZ'

#x holds the value of the encrypted message 

x=$(cat "test_input1_encrypted.txt")

#use tr to decrypt the message 

echo $x | tr $lowercase1 $lowercase | tr $uppercase1 $uppercase 